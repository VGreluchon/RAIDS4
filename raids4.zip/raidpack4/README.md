
You should merge this resource pack with SimplEnergy.
Manually or using this website https://mito.thenuclearnexus.live/
